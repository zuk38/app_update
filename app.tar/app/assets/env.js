(function(window) {
  window["env"] = window["env"] || {};

  // Environment variables
  window["env"]["apiUrl"] = '';
  window["env"]["spacedeckUrl"] = '';
  window["env"]["peerConnectionUrl"] = '';
  window["env"]["jitsiUrl"] = '';
})(this);
