(function(window) {
  window.env = window.env || {};

  // Environment variables
  window["env"]["apiUrl"] = "${API_URL}";
  window["env"]["spacedeckUrl"] = "${SPACEDECK_URL}";
  window["env"]["peerConnectionUrl"] = "${WEBRTC_SERVER_URL}";
  window["env"]["jitsiUrl"] = "${JITSI_URL}";
})(this);
